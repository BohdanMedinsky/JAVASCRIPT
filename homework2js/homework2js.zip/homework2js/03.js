let stor=Number(prompt('введіть довжину сторони квадрата'));
let x=Number(stor*stor);
alert(`площа квадрата зі стороною ${stor} дорівнює ${x}`);
let story=Number(prompt('введіть довжину 1 сторони прямокутника'));
let y=Number(prompt('введіть довжину 2 сторони прямокутника'));
let p=Number((story+y)*2);
alert(`периметр прямокутника, із сторонами ${story} та ${y} дорівнює: ${p}`);