let v = Number(prompt('введіть число'));
alert(`${v} у 2 степені буде ${Number(Math.pow(v,2))}, а\n${v} у 4 степені буде ${Number(Math.pow(v,4))}.`);