let a=Number(prompt('введіть 1 число'));
let a1=Number(prompt('введіть 2 число'));
let a2=Number(a+a1);
let a3=Number(a-a2);
let a4=Number(a*a2);
let a5=Number(a/a2);
alert(`${a}+${a1}=${a2},\n${a}-${a1}=${a3},\n${a}*${a1}=${a4},\n${a}/${a1}=${a5.toFixed(3)}.`);