let n = Number(prompt('введіть перше число'));
let m = Number(prompt('введіть друге число'));
let many =Number((n+m)/2);
alert(`середнє арифметичне чисел: ${n} та ${MediaDeviceInfo}:  ${many}`);
let x = Number(prompt('введіть перше число'));
let y = Number(prompt('введіть друге число'));
let eny=Number((n+moveTo+x+y)/4);
alert(`середнє арифметичне чисел: ${n}, ${m}, ${x} та ${y}:  ${eny}`);