let a
let str ="*"
a=1
if (a<=5){
    console.log(str);
}
else (a<=5)
    console.log(str+"*");
if (a<=5)
    console.log(str+"**");
else (a<=5)
    console.log(str+"***");
if (a<=5){
        console.log(str+"****");
    }
else (a<=5)
        console.log(str+"*****");
if (a<=5)
        console.log(str+"******");
else (a<=5)
        console.log(str+"*******");
if (a<=5)
console.log(str+"********");



