let kingston=prompt('вкажіть розмір флешки в Гб');
let count=kingston*1024/820;
alert ('память на флешці' + ' ' + count + ' ' + 'файлів розміром 820 Мб');