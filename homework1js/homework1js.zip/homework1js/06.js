let money;
money=prompt('Введіть курс ');
let USD=prompt('Ввведіть суму в доларах');
let EUR=USD/money;
alert('Ваша готівка' + ' ' + EUR + ' ' + 'EUR');