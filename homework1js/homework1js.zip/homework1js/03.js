var length;
length=prompt("Вкажіть довжину сторони квадрата.");
var A = length*4;
var B = length*length;
alert("периметр квадратe дорівнює:" + " " + A);
alert("площа квадрата дорівнює:" + " " + B);