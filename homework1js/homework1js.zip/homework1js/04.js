var radius;
radius=prompt("Вкажіть радіус кола");
var S = Math.PI * radius * radius;
alert("площа кола " + " " + S + ' ' + 'квадраних одиниць');